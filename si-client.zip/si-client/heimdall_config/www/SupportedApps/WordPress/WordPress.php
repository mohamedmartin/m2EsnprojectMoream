<?php namespace App\SupportedApps\WordPress;

class WordPress extends \App\SupportedApps
{
}
